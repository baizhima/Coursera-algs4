import java.util.Arrays;
public class Fast {
    public static void main(String[] args)
    {
        /*
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        StdDraw.show(0);
        // read in the input
        String filename = args[0];
        In in = new In(filename);
        int N = in.readInt();
        Point[] p = new Point[N]; 
        for (int i = 0; i < N; i++) {
            int x = in.readInt();
            int y = in.readInt();
            p[i] = new Point(x, y);     
        }
        Point p0 = new Point(0, 0);
        Arrays.sort(p, p0.SLOPE_ORDER);
        for (int i1 = 0; i1 < N - 3; i1++)            
            for (int i2 = i1 + 1; i2 < N - 2; i2++)               
                for (int i3 = i2 + 1; i3 < N -1; i3++)                   
                    for (int i4 = i3 + 1; i4 < N; i4++)
                    {
                        Point p1 = p[i1];
                        Point p2 = p[i2];
                        Point p3 = p[i3];
                        Point p4 = p[i4];
                        double k1, k2, k3;
                        k1 = p1.slopeTo(p2);
                        k2 = p1.slopeTo(p3);
                        k3 = p1.slopeTo(p4);
                        if (k1 == k2 && k1 == k3)
                        {
                            StdOut.println(p1.toString() + " -> "  
                                         +  p2.toString() + " -> "  
                                         +  p3.toString() + " -> " 
                                         +  p4.toString());
                            p1.draw();
                            p2.draw();
                            p3.draw();
                            p4.draw();
                            p1.drawTo(p4);
                            StdDraw.show(0);
                        }
                        
                    }
            
        */
    }
}
