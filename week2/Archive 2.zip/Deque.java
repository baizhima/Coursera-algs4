import java.util.Iterator;
import java.util.NoSuchElementException;
public class Deque<Item> implements Iterable<Item> {
    private int N;
    private Node<Item> first;
    
    private static class Node<Item> {
        private Item item;
        private Node<Item> next;
    }
    
    public Deque() {
        first = null;
        
        N = 0;
    }
    public boolean isEmpty() { return N == 0; }
    public int size() { return N; }
    public void addFirst(Item item) {
        if (item == null) throw new NullPointerException("null item");
        Node<Item> oldfirst = first;
        first = new Node<Item>();
        first.item = item;
        first.next = oldfirst;
        N++;
    }
    public void addLast(Item item) {
        if (N == 0)
            addFirst(item);
        else {
           if (item == null) throw new NullPointerException("null item");
           Node<Item> current;
           for (current = first; current.next != null; current = current.next) {
               // Empty statement
               int k = 0;
           }
               
           current.next = new Node<Item>();
           current.next.item = item;
           N++;
        }
        
    }
    public Item removeFirst() {
        if (isEmpty()) throw new NoSuchElementException();
        else {
        
        Item item = first.item;
        first = first.next;
        N--;
        if (N == 0)
            first = null;
        return item;
        
    }
    }
    public Item removeLast() { 
        if (isEmpty()) throw new NoSuchElementException();
        if (N == 1) 
            return removeFirst();
        else {
            Node<Item> current = first;
            for (int i = 0; i < N - 2; i++)
                current = current.next;
            Item deleteItem = current.next.item;
            current.next = null;
            N--;
            return deleteItem;
        }
    }        
        
        
    
    public Iterator<Item> iterator() {
        return new ListIterator();
    }
    
    
    
    private class ListIterator implements Iterator<Item> {
        private Node<Item> current = first;

        public boolean hasNext()  { return current != null;   }
        public void remove()      { throw new UnsupportedOperationException();  }

        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();
            Item item = current.item;
            current = current.next; 
            return item;
        }
    }
    
    public static void main(String[] args) {
        Deque<Integer> deque = new Deque<Integer>();
        Iterator<Integer> i = deque.iterator();
        Iterator<Integer> k = deque.iterator();
    }
}
        