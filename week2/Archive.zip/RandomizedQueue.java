import java.util.Iterator;
import java.util.NoSuchElementException;
//import java.util.NullPointerException;
public class RandomizedQueue<Item> implements Iterable<Item> {
    private Item[] q;            // queue elements
    private int N = 0;           // number of elements on queue
    private int first = 0;       // index of first element of queue
    private int last  = 0;       // index of next available slot
    public RandomizedQueue()
    {
        q = (Item[]) new Object[2];
    }
    
    public boolean isEmpty() { return N == 0;    }
    public int size()        { return N;         }
    public void enqueue(Item item) {
        if (item == null) throw new NullPointerException();
        if (N == q.length) resize(2 * q.length);
        q[N++] = item;
    }
        
    public Item dequeue() {
        if (N == 0) throw new NoSuchElementException();
        int idx = StdRandom.uniform(0,N);
        Item deleteItem = q[idx];
        for (int i = idx; i < N - 1; i++)
            q[i] = q[i + 1];
        N--;
        if (N > 0 && N == q.length/4) resize(q.length/2);
        return deleteItem;
    }
    
    public Item sample() {
        if (N == 0)
            throw new NoSuchElementException();
        int idx = StdRandom.uniform(0,N);
        return q[idx];
    }
    
    private void resize(int capacity) {
        assert capacity >= N;
        Item[] temp = (Item[]) new Object[capacity];
        for (int i = 0; i < N; i++) {
            temp[i] = q[i];
        }
        q = temp;
    }    
        
    public Iterator<Item> iterator() { return new ArrayIterator(); }

    // an iterator, doesn't implement remove() since it's optional
    private class ArrayIterator implements Iterator<Item> {
        private int i = 0;
        private int[] num = new int[N];
        for (int j = 0; j < N;j++)
            num[j] = j;
        StdRandom.shuffle(num);
        public boolean hasNext()  { return i < N;           }
        public void remove()      { throw new UnsupportedOperationException();  }

        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();
            Item item = q[i];
            i++;
            return item;
        }
    }
    
    public static void main(String[] args) {
        RandomizedQueue<Integer> rq = new RandomizedQueue<Integer>();
        try {
            rq.enqueue(null);
        } catch (NullPointerException e ) {
            StdOut.println("111");
        }
        for (int i = 0; i < 100; i++)
            rq.enqueue(i);
        //rq.enqueue(Integer.valueOf(7));
        //rq.enqueue(Integer.valueOf(8));
        StdOut.println(rq.dequeue());
        //Iterator<Integer> i = rq.iterator();
        for (Integer i :rq)
            StdOut.println(i);
    }
    
}
    