import java.util.Comparator;
import java.util.ArrayList;
public class Solver {
    //private Board board;
    private Board twin;
    private int moveCount;
    private Node lastNode;
    private ArrayList<Board> boardArray;
    
    public Solver(Board initial) {
    boardArray = new ArrayList<Board>();
    //boardArray.add(initial); // add the initial board into boardArray
    twin = initial.twin();
    moveCount = 0;
    MinPQ<Node> pq = new MinPQ<Node>();
    Node firstNode = new Node(initial,moveCount,null);
    pq.insert(firstNode);
    
    while (true) {
    //for (int i = 0; i < 5; i++)    {
    Node current = pq.delMin(); // select the node with least priority(min)
    Board currentBoard = current.getBoard(); // get the corresponding board
    //StdOut.println("currentBoard = \n"+currentBoard.toString());
    boardArray.add(currentBoard);
    if (currentBoard.isGoal())
        break;
    if (current != null) {
        moveCount += 1;
        for (Board b: currentBoard.neighbors()) {
        Node newNode = new Node(b,moveCount,current);
        if (lastNode != null) {
            if(!b.equals(lastNode.getBoard())){
            //StdOut.println("1we will add: \n");
            //StdOut.println(newNode.show());
            pq.insert(newNode);
            }
        }
        else
        {
            //StdOut.println("2we will add: \n");
            //StdOut.println(newNode.show());
            pq.insert(newNode);
        }
        }
        lastNode = current;
        //StdOut.println("MinPQ size = " + String.valueOf(pq.size()) + "\n");
        //StdOut.println("all boards in priority queue:\n");
        //for (Node node : pq)
            //StdOut.println(node.show());
    }
    else
        throw new NullPointerException("current Node is null");
    }
    StdOut.println("Minimum number of moves = "+ moveCount + "\n");
        for (Board b: boardArray)
            StdOut.println(b.toString());
    }
    public boolean isSolvable() { return false; }
    public int moves() { return moveCount; }
    //public Iterable<Board> solution() {}
    
    private class Node implements Comparable<Node> {
        private final String output;
        private final Board board;
        private final int priority;
        private final Node prev;
        private final int moves;
        
        
        public Node(Board b,int moves, Node lastNode) {
            board = b;
            priority = board.manhattan() + moves;
            output = board.toString();
            prev = lastNode;
            this.moves = moves;
        }
        
        public int compareTo(Node that) {
            if (this.priority < that.priority) return -1;
            else if (this.priority > that.priority) return +1;
            else return 0;
        }
        
        public String show() { 
            StringBuilder s = new StringBuilder();
            s.append("priority  = " + String.valueOf(priority) + "\n");
            s.append("moves     = " + String.valueOf(moves) + "\n");
            s.append("mahhattan = " + String.valueOf(board.manhattan()) + "\n");
            s.append(board.toString());
            return s.toString(); 
        }
        
        public Board getBoard() { return board; }
    }
    
    public static void main(String[] args) {
    for (String filename : args) {

            // read in the board specified in the filename
            In in = new In(filename);
            int N = in.readInt();
            int[][] tiles = new int[N][N];
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    tiles[i][j] = in.readInt();
                }
            }

            // solve the slider puzzle
            Board initial = new Board(tiles);
            //StdOut.println("initial="+initial.toString());
            Solver solver = new Solver(initial);
    }
    }
}
        